/*
  # Fix House Policies Final Version 2

  1. Changes
    - Further simplify policy logic to prevent recursion
    - Split policies into smaller, focused rules
    - Remove all nested EXISTS clauses
    - Use direct relationships for access control

  2. Security
    - Maintain proper access control
    - Ensure house owners retain full access
    - Allow members to view their houses
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "view_houses" ON houses;
DROP POLICY IF EXISTS "view_member_houses" ON houses;
DROP POLICY IF EXISTS "create_houses" ON houses;
DROP POLICY IF EXISTS "update_houses" ON houses;
DROP POLICY IF EXISTS "delete_houses" ON houses;
DROP POLICY IF EXISTS "view_house_members" ON house_members;
DROP POLICY IF EXISTS "view_owned_house_members" ON house_members;
DROP POLICY IF EXISTS "manage_house_members" ON house_members;
DROP POLICY IF EXISTS "view_sent_invitations" ON house_invitations;
DROP POLICY IF EXISTS "view_received_invitations" ON house_invitations;
DROP POLICY IF EXISTS "view_house_invitations" ON house_invitations;
DROP POLICY IF EXISTS "create_invitations" ON house_invitations;
DROP POLICY IF EXISTS "manage_invitations" ON house_invitations;

-- Houses policies (simplified)
CREATE POLICY "owner_access_houses"
  ON houses
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "member_view_houses"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT house_id
      FROM house_members
      WHERE member_id = auth.uid()
    )
  );

-- House members policies (simplified)
CREATE POLICY "member_view_own_memberships"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (member_id = auth.uid());

CREATE POLICY "owner_manage_members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- House invitations policies (simplified)
CREATE POLICY "inviter_view_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (invited_by = auth.uid());

CREATE POLICY "invitee_view_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    email = (
      SELECT email
      FROM auth.users
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "owner_manage_invitations"
  ON house_invitations
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);