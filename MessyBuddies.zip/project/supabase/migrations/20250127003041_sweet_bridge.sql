-- Drop existing policies
DROP POLICY IF EXISTS "select_owned_houses" ON houses;
DROP POLICY IF EXISTS "select_member_houses" ON houses;
DROP POLICY IF EXISTS "insert_houses" ON houses;
DROP POLICY IF EXISTS "update_owned_houses" ON houses;
DROP POLICY IF EXISTS "delete_owned_houses" ON houses;
DROP POLICY IF EXISTS "select_house_members" ON house_members;
DROP POLICY IF EXISTS "insert_house_members" ON house_members;
DROP POLICY IF EXISTS "delete_house_members" ON house_members;
DROP POLICY IF EXISTS "select_invitations" ON house_invitations;
DROP POLICY IF EXISTS "insert_invitations" ON house_invitations;
DROP POLICY IF EXISTS "update_invitations" ON house_invitations;

-- Simplified house members policies
CREATE POLICY "members_access"
  ON house_members
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Simplified house invitations policies
CREATE POLICY "invitations_access"
  ON house_invitations
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);