/*
  # Fix House Policies Final Version

  1. Changes
    - Simplify policy logic to prevent recursion
    - Use direct relationships for access control
    - Remove nested EXISTS clauses
    - Split complex policies into simpler ones

  2. Security
    - Maintain proper access control
    - Ensure house owners retain full access
    - Allow members to view their houses
*/

-- Drop all existing policies to start fresh
DROP POLICY IF EXISTS "owner_access_houses" ON houses;
DROP POLICY IF EXISTS "member_view_houses" ON houses;
DROP POLICY IF EXISTS "member_view_own_memberships" ON house_members;
DROP POLICY IF EXISTS "owner_manage_members" ON house_members;
DROP POLICY IF EXISTS "inviter_view_invitations" ON house_invitations;
DROP POLICY IF EXISTS "invitee_view_invitations" ON house_invitations;
DROP POLICY IF EXISTS "owner_manage_invitations" ON house_invitations;

-- Houses policies (simplified)
CREATE POLICY "owner_full_access"
  ON houses
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "member_read_access"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT house_id
      FROM house_members
      WHERE member_id = auth.uid()
    )
  );

-- House members policies (simplified)
CREATE POLICY "view_own_membership"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (member_id = auth.uid());

CREATE POLICY "owner_manage_house_members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- House invitations policies (simplified)
CREATE POLICY "view_own_invites"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    email = (
      SELECT email
      FROM auth.users
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "owner_manage_house_invites"
  ON house_invitations
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);