/*
  # Update House Member Policies

  1. Changes
    - Drop existing policies to avoid conflicts
    - Recreate policies with improved logic to prevent recursion
    - Add missing policies for house invitations
    - Update indexes for better performance

  2. Security
    - Maintain RLS for all tables
    - Ensure proper access control for house members and invitations
    - Prevent unauthorized access to house data

  3. Performance
    - Add appropriate indexes
    - Optimize policy queries
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view houses they are members of" ON houses;
DROP POLICY IF EXISTS "Users can create houses" ON houses;
DROP POLICY IF EXISTS "House owners can update their houses" ON houses;
DROP POLICY IF EXISTS "House owners can delete their houses" ON houses;
DROP POLICY IF EXISTS "Users can view house members" ON house_members;
DROP POLICY IF EXISTS "House owners can manage members" ON house_members;
DROP POLICY IF EXISTS "Users can view invitations they created" ON house_invitations;
DROP POLICY IF EXISTS "House owners can create invitations" ON house_invitations;
DROP POLICY IF EXISTS "House owners can manage invitations" ON house_invitations;

-- Recreate houses policies
CREATE POLICY "Users can view houses they are members of"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM house_members 
      WHERE house_members.house_id = houses.id 
      AND house_members.member_id = auth.uid()
    )
    OR owner_id = auth.uid()
  );

CREATE POLICY "Users can create houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "House owners can update their houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "House owners can delete their houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- Recreate house members policies
CREATE POLICY "Users can view members of their houses"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_members.house_id 
      AND (
        houses.owner_id = auth.uid()
        OR EXISTS (
          SELECT 1 
          FROM house_members AS my_membership
          WHERE my_membership.house_id = house_members.house_id 
          AND my_membership.member_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "House owners can manage members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_members.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

-- Recreate house invitations policies
CREATE POLICY "Users can view invitations for their houses"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid()
    OR email = (
      SELECT email 
      FROM auth.users 
      WHERE id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can create invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

-- Add or update indexes for better performance
DROP INDEX IF EXISTS idx_house_members_house_id;
DROP INDEX IF EXISTS idx_house_members_member_id;
DROP INDEX IF EXISTS idx_house_invitations_house_id;
DROP INDEX IF EXISTS idx_house_invitations_email;

CREATE INDEX idx_house_members_house_id ON house_members(house_id);
CREATE INDEX idx_house_members_member_id ON house_members(member_id);
CREATE INDEX idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX idx_house_invitations_email ON house_invitations(email);