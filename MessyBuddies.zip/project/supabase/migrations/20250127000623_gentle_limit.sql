-- Drop existing policies
DROP POLICY IF EXISTS "houses_select_policy" ON houses;
DROP POLICY IF EXISTS "houses_insert_policy" ON houses;
DROP POLICY IF EXISTS "houses_update_policy" ON houses;
DROP POLICY IF EXISTS "houses_delete_policy" ON houses;
DROP POLICY IF EXISTS "members_select_policy" ON house_members;
DROP POLICY IF EXISTS "members_insert_policy" ON house_members;
DROP POLICY IF EXISTS "members_delete_policy" ON house_members;
DROP POLICY IF EXISTS "invitations_select_policy" ON house_invitations;
DROP POLICY IF EXISTS "invitations_insert_policy" ON house_invitations;
DROP POLICY IF EXISTS "invitations_update_policy" ON house_invitations;

-- Simple, non-recursive policies for houses
CREATE POLICY "select_owned_houses"
  ON houses
  FOR SELECT
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "select_member_houses"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT house_id
      FROM house_members
      WHERE member_id = auth.uid()
    )
  );

CREATE POLICY "insert_houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "update_owned_houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "delete_owned_houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- Simple policies for house members
CREATE POLICY "select_house_members"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    member_id = auth.uid() OR
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_house_members"
  ON house_members
  FOR INSERT
  TO authenticated
  WITH CHECK (
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_house_members"
  ON house_members
  FOR DELETE
  TO authenticated
  USING (
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

-- Simple policies for house invitations
CREATE POLICY "select_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid() OR
    email = (SELECT email FROM auth.users WHERE id = auth.uid()) OR
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "update_invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    house_id IN (
      SELECT id FROM houses WHERE owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);
CREATE INDEX IF NOT EXISTS idx_houses_owner_id ON houses(owner_id);