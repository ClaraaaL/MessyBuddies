/*
  # Fix House Member Policies Recursion

  1. Changes
    - Simplify policy logic to prevent recursion
    - Optimize policy performance
    - Fix infinite recursion in house_members policies

  2. Security
    - Maintain proper access control
    - Ensure house owners retain full access
    - Allow members to view their houses
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can view houses they are members of" ON houses;
DROP POLICY IF EXISTS "Users can create houses" ON houses;
DROP POLICY IF EXISTS "House owners can update their houses" ON houses;
DROP POLICY IF EXISTS "House owners can delete their houses" ON houses;
DROP POLICY IF EXISTS "Users can view members of their houses" ON house_members;
DROP POLICY IF EXISTS "House owners can manage members" ON house_members;
DROP POLICY IF EXISTS "Users can view invitations for their houses" ON house_invitations;
DROP POLICY IF EXISTS "House owners can create invitations" ON house_invitations;
DROP POLICY IF EXISTS "House owners can manage invitations" ON house_invitations;

-- Houses policies
CREATE POLICY "Users can view houses they are members of"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid() OR
    id IN (
      SELECT house_id
      FROM house_members
      WHERE member_id = auth.uid()
    )
  );

CREATE POLICY "Users can create houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "House owners can update their houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "House owners can delete their houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- House members policies (simplified to prevent recursion)
CREATE POLICY "Users can view house members"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    member_id = auth.uid() OR
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- House invitations policies
CREATE POLICY "Users can view invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid() OR
    email = (
      SELECT email
      FROM auth.users
      WHERE id = auth.uid()
    ) OR
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can create invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);