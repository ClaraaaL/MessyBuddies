-- Create houses table
CREATE TABLE IF NOT EXISTS houses (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  name text NOT NULL,
  owner_id uuid REFERENCES profiles(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create house_members table
CREATE TABLE IF NOT EXISTS house_members (
  house_id uuid REFERENCES houses(id) ON DELETE CASCADE,
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member',
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (house_id, member_id)
);

-- Create house_invitations table
CREATE TABLE IF NOT EXISTS house_invitations (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  house_id uuid REFERENCES houses(id) ON DELETE CASCADE,
  email text NOT NULL,
  invited_by uuid REFERENCES profiles(id),
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '7 days')
);

-- Enable RLS
ALTER TABLE houses ENABLE ROW LEVEL SECURITY;
ALTER TABLE house_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE house_invitations ENABLE ROW LEVEL SECURITY;

-- Houses policies
CREATE POLICY "Users can view houses they are members of"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM house_members 
      WHERE house_members.house_id = houses.id 
      AND house_members.member_id = auth.uid()
    )
    OR owner_id = auth.uid()
  );

CREATE POLICY "Users can create houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "House owners can update their houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "House owners can delete their houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- House members policies
CREATE POLICY "Users can view members of their houses"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_members.house_id 
      AND (
        houses.owner_id = auth.uid()
        OR EXISTS (
          SELECT 1 
          FROM house_members AS my_membership
          WHERE my_membership.house_id = houses.id 
          AND my_membership.member_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "House owners can manage members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_members.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

-- House invitations policies
CREATE POLICY "Users can view invitations for their houses"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid()
    OR email = (
      SELECT email 
      FROM auth.users 
      WHERE id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can create invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM houses 
      WHERE houses.id = house_invitations.house_id 
      AND houses.owner_id = auth.uid()
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);