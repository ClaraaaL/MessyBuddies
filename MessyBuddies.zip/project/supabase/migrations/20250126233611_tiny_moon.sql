/*
  # Add house member management

  1. New Tables
    - `houses`
      - `id` (uuid, primary key)
      - `name` (text)
      - `created_at` (timestamp)
      - `owner_id` (uuid, references profiles)
      
    - `house_members`
      - `house_id` (uuid, references houses)
      - `member_id` (uuid, references profiles)
      - `role` (text)
      - `created_at` (timestamp)

    - `house_invitations`
      - `id` (uuid, primary key)
      - `house_id` (uuid, references houses)
      - `email` (text)
      - `invited_by` (uuid, references profiles)
      - `status` (text)
      - `created_at` (timestamp)
      - `expires_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for house access and management
*/

-- Create houses table
CREATE TABLE IF NOT EXISTS houses (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  name text NOT NULL,
  owner_id uuid REFERENCES profiles(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create house_members table
CREATE TABLE IF NOT EXISTS house_members (
  house_id uuid REFERENCES houses(id) ON DELETE CASCADE,
  member_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member',
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (house_id, member_id)
);

-- Create house_invitations table
CREATE TABLE IF NOT EXISTS house_invitations (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  house_id uuid REFERENCES houses(id) ON DELETE CASCADE,
  email text NOT NULL,
  invited_by uuid REFERENCES profiles(id),
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '7 days')
);

-- Enable RLS
ALTER TABLE houses ENABLE ROW LEVEL SECURITY;
ALTER TABLE house_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE house_invitations ENABLE ROW LEVEL SECURITY;

-- Houses policies
CREATE POLICY "Users can view houses they are members of"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT house_id 
      FROM house_members 
      WHERE member_id = auth.uid()
    )
    OR owner_id = auth.uid()
  );

CREATE POLICY "Users can create houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "House owners can update their houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "House owners can delete their houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- House members policies
CREATE POLICY "Users can view house members"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    house_id IN (
      SELECT id 
      FROM houses 
      WHERE id IN (
        SELECT house_id 
        FROM house_members 
        WHERE member_id = auth.uid()
      )
      OR owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id 
      FROM houses 
      WHERE owner_id = auth.uid()
    )
  );

-- House invitations policies
CREATE POLICY "Users can view invitations they created"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid()
    OR email = (
      SELECT email 
      FROM auth.users 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "House owners can create invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    house_id IN (
      SELECT id 
      FROM houses 
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "House owners can manage invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    house_id IN (
      SELECT id 
      FROM houses 
      WHERE owner_id = auth.uid()
    )
  );