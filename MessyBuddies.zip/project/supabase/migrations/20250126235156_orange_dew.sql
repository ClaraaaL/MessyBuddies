/*
  # Fix House Policies Final Version

  1. Changes
    - Further simplify policy logic to prevent recursion
    - Remove all nested subqueries
    - Use direct relationships for access control

  2. Security
    - Maintain proper access control
    - Ensure house owners retain full access
    - Allow members to view their houses
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can view houses they are members of" ON houses;
DROP POLICY IF EXISTS "Users can create houses" ON houses;
DROP POLICY IF EXISTS "House owners can update their houses" ON houses;
DROP POLICY IF EXISTS "House owners can delete their houses" ON houses;
DROP POLICY IF EXISTS "Users can view house members" ON house_members;
DROP POLICY IF EXISTS "House owners can manage members" ON house_members;
DROP POLICY IF EXISTS "Users can view invitations" ON house_invitations;
DROP POLICY IF EXISTS "House owners can create invitations" ON house_invitations;
DROP POLICY IF EXISTS "House owners can manage invitations" ON house_invitations;

-- Houses policies (simplified)
CREATE POLICY "view_houses"
  ON houses
  FOR SELECT
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "view_member_houses"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT house_id
      FROM house_members
      WHERE member_id = auth.uid()
    )
  );

CREATE POLICY "create_houses"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "update_houses"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "delete_houses"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- House members policies (simplified)
CREATE POLICY "view_house_members"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (member_id = auth.uid());

CREATE POLICY "view_owned_house_members"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "manage_house_members"
  ON house_members
  FOR ALL
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- House invitations policies (simplified)
CREATE POLICY "view_sent_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (invited_by = auth.uid());

CREATE POLICY "view_received_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    email = (
      SELECT email
      FROM auth.users
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "view_house_invitations"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "create_invitations"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "manage_invitations"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    house_id IN (
      SELECT id
      FROM houses
      WHERE owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);