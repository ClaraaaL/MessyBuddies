/*
  # Fix House Policies Final Version

  1. Changes
    - Remove all existing policies
    - Create new simplified policies without recursion
    - Add performance indexes
  
  2. Security
    - Enable RLS on all tables
    - Add policies for houses, members, and invitations
    - Ensure proper access control
*/

-- Drop all existing policies to start fresh
DROP POLICY IF EXISTS "owner_full_access" ON houses;
DROP POLICY IF EXISTS "member_read_access" ON houses;
DROP POLICY IF EXISTS "view_own_membership" ON house_members;
DROP POLICY IF EXISTS "owner_manage_house_members" ON house_members;
DROP POLICY IF EXISTS "view_own_invites" ON house_invitations;
DROP POLICY IF EXISTS "owner_manage_house_invites" ON house_invitations;

-- Houses policies
CREATE POLICY "houses_select_policy"
  ON houses
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid() OR
    EXISTS (
      SELECT 1
      FROM house_members
      WHERE house_members.house_id = houses.id
      AND house_members.member_id = auth.uid()
    )
  );

CREATE POLICY "houses_insert_policy"
  ON houses
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "houses_update_policy"
  ON houses
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "houses_delete_policy"
  ON houses
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- House members policies
CREATE POLICY "members_select_policy"
  ON house_members
  FOR SELECT
  TO authenticated
  USING (
    member_id = auth.uid() OR
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_members.house_id
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "members_insert_policy"
  ON house_members
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_members.house_id
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "members_delete_policy"
  ON house_members
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_members.house_id
      AND houses.owner_id = auth.uid()
    )
  );

-- House invitations policies
CREATE POLICY "invitations_select_policy"
  ON house_invitations
  FOR SELECT
  TO authenticated
  USING (
    invited_by = auth.uid() OR
    email = (SELECT email FROM auth.users WHERE id = auth.uid()) OR
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_invitations.house_id
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "invitations_insert_policy"
  ON house_invitations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_invitations.house_id
      AND houses.owner_id = auth.uid()
    )
  );

CREATE POLICY "invitations_update_policy"
  ON house_invitations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM houses
      WHERE houses.id = house_invitations.house_id
      AND houses.owner_id = auth.uid()
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_house_members_house_id ON house_members(house_id);
CREATE INDEX IF NOT EXISTS idx_house_members_member_id ON house_members(member_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_house_id ON house_invitations(house_id);
CREATE INDEX IF NOT EXISTS idx_house_invitations_email ON house_invitations(email);
CREATE INDEX IF NOT EXISTS idx_houses_owner_id ON houses(owner_id);