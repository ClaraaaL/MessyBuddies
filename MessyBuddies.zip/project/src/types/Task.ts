export interface Task {
  id: string;
  name: string;
  description: string;
  assignedMemberId: string;
  dueDate: Date;
  progress: number;
  status: 'completed' | 'in_progress';
  category: 'housework' | 'homework' | 'shopping';
  createdAt: Date;
  updatedAt: Date;
}

export interface FamilyMember {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'admin' | 'member';
  createdAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'task_update' | 'deadline' | 'new_assignment' | 'task_approval';
  message: string;
  taskId?: string;
  read: boolean;
  createdAt: Date;
}