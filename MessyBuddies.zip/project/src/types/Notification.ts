export type NotificationType = 'task_assigned' | 'task_due_soon' | 'task_overdue' | 'task_updated';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  taskId?: string;
  read: boolean;
  createdAt: Date;
}

export interface NotificationPreferences {
  dueSoonReminder: number; // minutes before due date
  enablePushNotifications: boolean;
  enableEmailNotifications: boolean;
}