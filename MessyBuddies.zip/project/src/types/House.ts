export interface House {
  id: string;
  name: string;
  owner_id: string;
  created_at: string;
}

export interface HouseMember {
  member_id: string;
  role: 'owner' | 'member';
  created_at: string;
  profiles?: {
    id: string;
    name: string | null;
    email: string;
  };
}

export interface HouseInvitation {
  id: string;
  email: string;
  invited_by: string;
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
  expires_at: string;
}