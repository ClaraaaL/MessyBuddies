import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { HomeScreen } from './screens/HomeScreen';
import { TaskDetailsScreen } from './screens/TaskDetailsScreen';
import { CreateTaskScreen } from './screens/CreateTaskScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { LoginScreen } from './screens/LoginScreen';
import { MembersScreen } from './screens/MembersScreen';
import { Layout } from './components/Layout';
import { TaskProvider } from './context/TaskContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthProvider } from './context/AuthContext';
import { HouseProvider } from './context/HouseContext';
import { useAuth } from './context/AuthContext';
import { Toaster } from 'react-hot-toast';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user) {
    return <Navigate to="/" />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <HouseProvider>
        <TaskProvider>
          <NotificationProvider>
            <BrowserRouter>
              <Toaster position="top-right" />
              <Routes>
                <Route
                  path="/login"
                  element={
                    <PublicRoute>
                      <LoginScreen />
                    </PublicRoute>
                  }
                />
                <Route
                  path="/"
                  element={
                    <PrivateRoute>
                      <Layout />
                    </PrivateRoute>
                  }
                >
                  <Route index element={<HomeScreen />} />
                  <Route path="task/:taskId" element={<TaskDetailsScreen />} />
                  <Route path="create-task" element={<CreateTaskScreen />} />
                  <Route path="calendar" element={<CalendarScreen />} />
                  <Route path="members" element={<MembersScreen />} />
                </Route>
              </Routes>
            </BrowserRouter>
          </NotificationProvider>
        </TaskProvider>
      </HouseProvider>
    </AuthProvider>
  );
}