import React, { useState } from 'react';
import { useHouse } from '../context/HouseContext';
import { HouseMember } from '../types/House';
import { UserCircleIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export function MembersScreen() {
  const { members, invitations, inviteMember, removeMember } = useHouse();
  const { user } = useAuth();
  const [email, setEmail] = useState('');

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error('Please enter an email address');
      return;
    }

    try {
      await inviteMember(email);
      setEmail('');
    } catch (error) {
      console.error('Error inviting member:', error);
    }
  };

  const handleRemoveMember = async (member: HouseMember) => {
    if (member.member_id === user?.id) {
      toast.error('You cannot remove yourself');
      return;
    }

    if (window.confirm(`Are you sure you want to remove ${member.profiles?.name || member.profiles?.email || 'this member'}?`)) {
      try {
        await removeMember(member.member_id);
      } catch (error) {
        console.error('Error removing member:', error);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow p-6">
      <h1 className="text-2xl font-bold mb-6">Members</h1>

      {/* Invite Form */}
      <div className="mb-8 bg-gray-50 p-4 rounded-lg">
        <h2 className="text-lg font-semibold mb-4">Invite New Member</h2>
        <form onSubmit={handleInvite} className="flex gap-2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email address"
            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark transition-colors"
          >
            Send Invite
          </button>
        </form>
      </div>

      {/* Members List */}
      <div className="space-y-6">
        <h2 className="text-lg font-semibold">Current Members</h2>
        <div className="divide-y">
          {members.map((member) => (
            <div key={member.member_id} className="py-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <UserCircleIcon className="h-10 w-10 text-gray-400" />
                <div>
                  <p className="font-medium">
                    {member.member_id === user?.id ? 'Me' : (member.profiles?.name || member.profiles?.email || 'Unknown Member')}
                  </p>
                  <p className="text-sm text-gray-500">{member.profiles?.email}</p>
                  <span className="text-xs text-primary bg-primary-light px-2 py-1 rounded-full">
                    {member.role}
                  </span>
                </div>
              </div>
              {member.member_id !== user?.id && (
                <button
                  onClick={() => handleRemoveMember(member)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                >
                  <XMarkIcon className="h-5 w-5" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Pending Invitations */}
        {invitations.length > 0 && (
          <div className="mt-8">
            <h2 className="text-lg font-semibold mb-4">Pending Invitations</h2>
            <div className="divide-y">
              {invitations.map((invitation) => (
                <div key={invitation.id} className="py-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium">{invitation.email}</p>
                    <p className="text-sm text-gray-500">
                      Invited {new Date(invitation.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span className="text-sm text-yellow-600 bg-yellow-50 px-3 py-1 rounded-full">
                    Pending
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}