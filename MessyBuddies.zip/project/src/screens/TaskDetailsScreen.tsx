import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTaskContext } from '../context/TaskContext';
import { format } from 'date-fns';
import { Task } from '../types/Task';
import { PencilIcon, CheckIcon, XMarkIcon } from '@heroicons/react/24/outline';

export function TaskDetailsScreen() {
  const { taskId } = useParams();
  const navigate = useNavigate();
  const { tasks, updateTask, deleteTask } = useTaskContext();
  const [isEditing, setIsEditing] = useState(false);

  const task = tasks.find(t => t.id === taskId);

  const [editForm, setEditForm] = useState<Partial<Task>>({
    name: task?.name || '',
    description: task?.description || '',
    dueDate: task?.dueDate ? format(new Date(task.dueDate), "yyyy-MM-dd'T'HH:mm") : '',
    category: task?.category || 'housework',
    assignedMemberId: task?.assignedMemberId || ''
  });

  if (!task) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold mb-6">Task Not Found</h1>
        <button
          onClick={() => navigate('/')}
          className="text-blue-600 hover:text-blue-800"
        >
          ← Back to Tasks
        </button>
      </div>
    );
  }

  const handleEdit = () => {
    setIsEditing(true);
    setEditForm({
      name: task.name,
      description: task.description,
      dueDate: format(new Date(task.dueDate), "yyyy-MM-dd'T'HH:mm"),
      category: task.category,
      assignedMemberId: task.assignedMemberId
    });
  };

  const handleSave = () => {
    if (!editForm.name || !editForm.dueDate) {
      alert('Name and due date are required!');
      return;
    }

    updateTask(task.id, {
      ...task,
      ...editForm,
      dueDate: new Date(editForm.dueDate),
      updatedAt: new Date()
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      deleteTask(task.id);
      navigate('/');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  };

  const getAssignedMemberName = (id: string) => {
    return id === '1' ? 'John Doe' : 'Jane Doe';
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-start mb-6">
        <button
          onClick={() => navigate('/')}
          className="text-blue-600 hover:text-blue-800"
        >
          ← Back to Tasks
        </button>
        <div className="flex space-x-2">
          {!isEditing && (
            <>
              <button
                onClick={handleEdit}
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                <PencilIcon className="w-4 h-4 mr-1" />
                Edit
              </button>
              <button
                onClick={handleDelete}
                className="flex items-center px-3 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
              >
                <XMarkIcon className="w-4 h-4 mr-1" />
                Delete
              </button>
            </>
          )}
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Task Name *
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={editForm.name}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              value={editForm.description}
              onChange={handleChange}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700">
              Category *
            </label>
            <select
              id="category"
              name="category"
              value={editForm.category}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            >
              <option value="housework">Housework</option>
              <option value="homework">Homework</option>
              <option value="shopping">Shopping</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Assigned To
            </label>
            <div className="mt-1 block w-full p-2 bg-gray-50 rounded-md border border-gray-300 text-gray-700">
              {getAssignedMemberName(task.assignedMemberId)}
            </div>
          </div>

          <div>
            <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700">
              Due Date *
            </label>
            <input
              type="datetime-local"
              id="dueDate"
              name="dueDate"
              value={editForm.dueDate}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={handleCancel}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
            >
              Save Changes
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold">{task.name}</h1>
            <span className={`inline-block px-2 py-1 text-sm rounded-full mt-2 ${
              task.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
            }`}>
              {task.status === 'completed' ? 'Completed' : 'In Progress'}
            </span>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">Description</h2>
            <p className="text-gray-600">{task.description || 'No description provided'}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h2 className="text-lg font-semibold mb-2">Category</h2>
              <p className="text-gray-600 capitalize">{task.category}</p>
            </div>
            <div>
              <h2 className="text-lg font-semibold mb-2">Assigned To</h2>
              <p className="text-gray-600">
                {getAssignedMemberName(task.assignedMemberId)}
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">Due Date</h2>
            <p className="text-gray-600">
              {format(new Date(task.dueDate), 'PPP p')}
            </p>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">Progress</h2>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  task.status === 'completed' ? 'bg-green-500' : 'bg-blue-500'
                }`}
                style={{ width: `${task.progress}%` }}
              />
            </div>
            <span className="text-sm text-gray-600">
              {task.status === 'completed' ? 'Completed' : `${task.progress}% Complete`}
            </span>
          </div>

          <div className="border-t pt-4">
            <div className="text-sm text-gray-500">
              <p>Created: {format(new Date(task.createdAt), 'PPP p')}</p>
              <p>Last Updated: {format(new Date(task.updatedAt), 'PPP p')}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}