import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Task } from '../types/Task';
import { useTaskContext } from '../context/TaskContext';
import { useAuth } from '../context/AuthContext';
import { useHouse } from '../context/HouseContext';
import toast from 'react-hot-toast';

export function CreateTaskScreen() {
  const navigate = useNavigate();
  const { addTask } = useTaskContext();
  const { user } = useAuth();
  const { members } = useHouse();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    dueDate: '',
    category: 'housework' as Task['category'],
    assignedMemberId: user?.id || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.dueDate || !formData.assignedMemberId) {
      toast.error('Please fill in all required fields');
      return;
    }

    addTask({
      name: formData.name,
      description: formData.description,
      dueDate: new Date(formData.dueDate),
      category: formData.category,
      assignedMemberId: formData.assignedMemberId,
      status: 'in_progress'
    });

    toast.success('Task created successfully!');
    navigate('/');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow p-6">
      <h1 className="text-2xl font-bold mb-6">Create New Task</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Task Name *
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700">
            Category *
          </label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="housework">Housework</option>
            <option value="homework">Homework</option>
            <option value="shopping">Shopping</option>
          </select>
        </div>

        <div>
          <label htmlFor="assignedMemberId" className="block text-sm font-medium text-gray-700">
            Assign To *
          </label>
          <select
            id="assignedMemberId"
            name="assignedMemberId"
            value={formData.assignedMemberId}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select a member</option>
            <option value={user?.id}>Myself ({user?.email})</option>
            {members.map(member => (
              member.member_id !== user?.id && (
                <option key={member.member_id} value={member.member_id}>
                  {member.profiles?.name || member.profiles?.email || 'Unknown Member'}
                </option>
              )
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700">
            Due Date *
          </label>
          <input
            type="datetime-local"
            id="dueDate"
            name="dueDate"
            value={formData.dueDate}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
          >
            Create Task
          </button>
        </div>
      </form>
    </div>
  );
}