import React, { useState } from 'react';
import { TaskList } from '../components/TaskList';
import { useTaskContext } from '../context/TaskContext';

export function HomeScreen() {
  const { tasks, toggleTaskStatus, deleteTask } = useTaskContext();
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'in_progress' | 'overdue'>('all');

  const filteredTasks = tasks.filter(task => {
    const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
    
    switch (statusFilter) {
      case 'completed':
        return task.status === 'completed';
      case 'in_progress':
        return task.status === 'in_progress';
      case 'overdue':
        return isOverdue;
      default:
        return true;
    }
  });

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white/80 backdrop-blur-sm rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">MessyBuddies Tasks</h1>
          <div className="flex space-x-4">
            <select
              className="rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
            >
              <option value="all">All Tasks</option>
              <option value="completed">Completed</option>
              <option value="in_progress">In Progress</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>
        </div>
      </div>
      <TaskList
        tasks={filteredTasks}
        onToggleStatus={toggleTaskStatus}
        onDeleteTask={deleteTask}
      />
      {filteredTasks.length === 0 && (
        <div className="text-center py-8 bg-white/80 backdrop-blur-sm rounded-lg">
          <p className="text-gray-500">
            No {statusFilter === 'all' ? '' : statusFilter} tasks found
          </p>
        </div>
      )}
    </div>
  );
}