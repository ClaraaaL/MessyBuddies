import React from 'react';
import { Calendar, dateFnsLocalizer, View } from 'react-big-calendar';
import { useNavigate } from 'react-router-dom';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import enUS from 'date-fns/locale/en-US';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Task } from '../types/Task';
import { useTaskContext } from '../context/TaskContext';

const locales = {
  'en-US': enUS
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
  resource?: any;
}

export function CalendarScreen() {
  const [view, setView] = React.useState<View>('month');
  const { tasks } = useTaskContext();
  const navigate = useNavigate();

  const events: CalendarEvent[] = tasks.map(task => ({
    id: task.id,
    title: task.name,
    start: new Date(task.dueDate),
    end: new Date(task.dueDate),
    allDay: true,
    resource: task,
  }));

  const eventStyleGetter = (event: CalendarEvent) => {
    const task = event.resource as Task;
    const backgroundColor = task.status === 'completed' ? '#10B981' : '#3B82F6';
    
    return {
      style: {
        backgroundColor,
        borderRadius: '4px',
        opacity: 0.8,
        color: 'white',
        border: 'none',
        display: 'block',
        cursor: 'pointer',
      },
    };
  };

  const handleEventClick = (event: CalendarEvent) => {
    navigate(`/task/${event.id}`);
  };

  return (
    <div className="p-4">
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold mb-6">Family Calendar</h1>
        <div style={{ height: 600 }}>
          <Calendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            style={{ height: '100%' }}
            eventPropGetter={eventStyleGetter}
            view={view}
            onView={setView as any}
            views={['month', 'week', 'day']}
            defaultView="month"
            popup
            onSelectEvent={handleEventClick}
            tooltipAccessor={(event) => {
              const task = (event as CalendarEvent).resource as Task;
              return `${task.name} - ${task.status === 'completed' ? 'Completed' : `${task.progress}% Complete`}`;
            }}
          />
        </div>
      </div>
    </div>
  );
}