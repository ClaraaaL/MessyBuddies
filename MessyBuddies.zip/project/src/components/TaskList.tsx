import React from 'react';
import { Task } from '../types/Task';
import { TaskCard } from './TaskCard';

interface TaskListProps {
  tasks: Task[];
  onToggleStatus: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
}

export function TaskList({ tasks, onToggleStatus, onDeleteTask }: TaskListProps) {
  return (
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
      {tasks.map((task) => (
        <TaskCard
          key={task.id}
          task={task}
          onComplete={onToggleStatus}
          onDelete={onDeleteTask}
        />
      ))}
    </div>
  );
}