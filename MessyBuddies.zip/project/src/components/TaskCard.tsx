import React from 'react';
import { Link } from 'react-router-dom';
import { Task } from '../types/Task';
import { CheckCircleIcon, ClockIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';
import { format } from 'date-fns';

interface TaskCardProps {
  task: Task;
  onComplete: (taskId: string) => void;
  onDelete: (taskId: string) => void;
}

export function TaskCard({ task, onComplete, onDelete }: TaskCardProps) {
  const progressWidth = task.status === 'completed' ? '100%' : `${task.progress}%`;
  const progressColor = task.status === 'completed' ? 'bg-green-500' : 'bg-primary';
  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const assignedMemberAvatar = task.assignedMemberId === '1' 
    ? 'https://ui-avatars.com/api/?name=John+Doe&background=8B5CF6&color=fff'
    : 'https://ui-avatars.com/api/?name=Jane+Doe&background=8B5CF6&color=fff';

  return (
    <div className={`bg-white/90 backdrop-blur-sm rounded-lg shadow p-4 hover:shadow-md transition-shadow ${
      isOverdue ? 'border-l-4 border-red-500' : ''
    }`}>
      <div className="flex justify-between items-start">
        <div className="flex items-start space-x-3">
          <img
            src={assignedMemberAvatar}
            alt="Assigned to"
            className="w-10 h-10 rounded-full"
          />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              {task.name}
              {isOverdue && (
                <ExclamationCircleIcon className="w-5 h-5 ml-2 text-red-500" title="Overdue" />
              )}
            </h3>
            <p className={`text-sm mt-1 flex items-center ${
              isOverdue ? 'text-red-500' : 'text-gray-500'
            }`}>
              <ClockIcon className="inline-block w-4 h-4 mr-1" />
              Due {format(new Date(task.dueDate), 'MMM d, yyyy')}
              {isOverdue && ' (Overdue)'}
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => onComplete(task.id)}
            className={`p-2 rounded-full transition-colors ${
              task.status === 'completed'
                ? 'text-green-600 bg-green-100'
                : 'text-gray-400 hover:text-primary hover:bg-primary-light'
            }`}
            title={task.status === 'completed' ? 'Mark as incomplete' : 'Mark as complete'}
          >
            <CheckCircleIcon className="w-5 h-5" />
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-2 rounded-full text-gray-400 hover:text-red-600 hover:bg-red-100"
            title="Delete task"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
          <div
            className={`h-2 rounded-full transition-all duration-300 ${progressColor}`}
            style={{ width: progressWidth }}
          />
        </div>
        <div className="flex justify-between items-center mt-1">
          <span className="text-sm text-gray-600">
            {task.status === 'completed' ? 'Completed' : `${task.progress}% Complete`}
          </span>
          {task.status === 'completed' && (
            <span className="text-sm text-green-600">✓ Done</span>
          )}
        </div>
      </div>

      <Link
        to={`/task/${task.id}`}
        className="mt-4 inline-block text-sm text-primary hover:text-primary-dark"
      >
        View Details →
      </Link>
    </div>
  );
}