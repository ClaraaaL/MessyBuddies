import React from 'react';
import { Link } from 'react-router-dom';
import { PlusIcon, CalendarIcon, HomeIcon, UserGroupIcon } from '@heroicons/react/24/outline';
import { NotificationBell } from './NotificationBell';
import { useAuth } from '../context/AuthContext';

export function Navbar() {
  const { user, signOut } = useAuth();

  return (
    <nav className="bg-primary text-white shadow">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-xl font-bold flex items-center">
              <HomeIcon className="h-6 w-6 mr-2" />
              MessyBuddies
            </Link>
            <Link to="/calendar" className="flex items-center hover:text-primary-light">
              <CalendarIcon className="h-5 w-5 mr-1" />
              Calendar
            </Link>
            <Link to="/members" className="flex items-center hover:text-primary-light">
              <UserGroupIcon className="h-5 w-5 mr-1" />
              Members
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <NotificationBell />
            <Link
              to="/create-task"
              className="inline-flex items-center px-4 py-2 rounded-md bg-white text-primary hover:bg-primary-light transition-colors"
            >
              <PlusIcon className="h-5 w-5 mr-1" />
              Add Task
            </Link>
            <div className="flex items-center space-x-3">
              <span className="text-sm">{user?.email}</span>
              <button
                onClick={() => signOut()}
                className="px-3 py-1 text-sm bg-primary-dark hover:bg-primary-darker rounded-md transition-colors"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}