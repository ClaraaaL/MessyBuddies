import React, { useState } from 'react';
import { BellIcon } from '@heroicons/react/24/outline';
import { NotificationCenter } from './NotificationCenter';
import { useNotificationContext } from '../context/NotificationContext';

export function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  const {
    notifications,
    unreadCount,
    markAsRead,
    deleteNotification,
    clearAllNotifications,
  } = useNotificationContext();

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="relative p-2 text-gray-100 hover:text-white"
      >
        <BellIcon className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full">
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <NotificationCenter
          notifications={notifications}
          unreadCount={unreadCount}
          onMarkAsRead={markAsRead}
          onDelete={deleteNotification}
          onClearAll={clearAllNotifications}
          onClose={() => setIsOpen(false)}
        />
      )}
    </>
  );
}