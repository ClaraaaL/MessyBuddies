export type MainStackParamList = {
  Home: undefined;
  TaskDetails: { taskId: string };
  CreateTask: undefined;
  Calendar: undefined;
  Profile: undefined;
};