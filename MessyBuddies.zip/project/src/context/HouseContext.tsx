import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { HouseMember, HouseInvitation } from '../types/House';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

interface HouseContextType {
  members: HouseMember[];
  invitations: HouseInvitation[];
  loading: boolean;
  inviteMember: (email: string) => Promise<void>;
  removeMember: (memberId: string) => Promise<void>;
}

const HouseContext = createContext<HouseContextType | undefined>(undefined);

export function HouseProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [members, setMembers] = useState<HouseMember[]>([]);
  const [invitations, setInvitations] = useState<HouseInvitation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchMembers();
      fetchInvitations();
    }
  }, [user]);

  const fetchMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('house_members')
        .select(`
          member_id,
          role,
          created_at,
          profiles:member_id (
            id,
            name,
            email
          )
        `);

      if (error) throw error;
      setMembers(data || []);
    } catch (error) {
      console.error('Error fetching members:', error);
      toast.error('Failed to fetch members');
    } finally {
      setLoading(false);
    }
  };

  const fetchInvitations = async () => {
    try {
      const { data, error } = await supabase
        .from('house_invitations')
        .select('*')
        .eq('status', 'pending');

      if (error) throw error;
      setInvitations(data || []);
    } catch (error) {
      console.error('Error fetching invitations:', error);
      toast.error('Failed to fetch invitations');
    }
  };

  const inviteMember = async (email: string) => {
    if (!user) return;

    try {
      // First check if the user is already a member
      const { data: existingProfiles, error: profileError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email);

      if (profileError) throw profileError;

      if (existingProfiles?.length > 0) {
        const memberId = existingProfiles[0].id;
        const { data: existingMembers, error: memberError } = await supabase
          .from('house_members')
          .select('*')
          .eq('member_id', memberId);

        if (memberError) throw memberError;

        if (existingMembers?.length > 0) {
          toast.error('This user is already a member');
          return;
        }
      }

      // Then check if there's already a pending invitation
      const { data: existingInvites, error: inviteError } = await supabase
        .from('house_invitations')
        .select('*')
        .eq('email', email)
        .eq('status', 'pending');

      if (inviteError) throw inviteError;

      if (existingInvites?.length > 0) {
        toast.error('An invitation has already been sent to this email');
        return;
      }

      // Create the invitation
      const { error } = await supabase
        .from('house_invitations')
        .insert({
          email,
          invited_by: user.id,
          status: 'pending'
        });

      if (error) throw error;

      // Send email invitation using Supabase Edge Function
      const { error: functionError } = await supabase.functions.invoke('send-invitation-email', {
        body: { email, invitedBy: user.email }
      });

      if (functionError) {
        console.error('Error sending invitation email:', functionError);
        toast.error('Invitation created but email could not be sent');
      } else {
        toast.success('Invitation sent successfully!');
      }

      fetchInvitations();
    } catch (error) {
      console.error('Error inviting member:', error);
      toast.error('Failed to send invitation');
      throw error;
    }
  };

  const removeMember = async (memberId: string) => {
    try {
      const { error } = await supabase
        .from('house_members')
        .delete()
        .eq('member_id', memberId);

      if (error) throw error;
      toast.success('Member removed successfully!');
      fetchMembers();
    } catch (error) {
      console.error('Error removing member:', error);
      toast.error('Failed to remove member');
      throw error;
    }
  };

  return (
    <HouseContext.Provider
      value={{
        members,
        invitations,
        loading,
        inviteMember,
        removeMember,
      }}
    >
      {children}
    </HouseContext.Provider>
  );
}

export function useHouse() {
  const context = useContext(HouseContext);
  if (context === undefined) {
    throw new Error('useHouse must be used within a HouseProvider');
  }
  return context;
}