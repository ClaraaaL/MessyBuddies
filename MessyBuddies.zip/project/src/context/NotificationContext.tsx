import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { Notification, NotificationType } from '../types/Notification';
import { useTaskContext } from './TaskContext';
import toast from 'react-hot-toast';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (notificationId: string) => void;
  clearAllNotifications: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

let notificationCounter = 0;

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { tasks } = useTaskContext();
  const notificationsRef = useRef<Notification[]>(notifications);

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    notificationsRef.current = notifications;
  }, [notifications]);

  const addNotification = useCallback(({ type, title, message, taskId }: {
    type: NotificationType;
    title: string;
    message: string;
    taskId?: string;
  }) => {
    const notification: Notification = {
      id: `notification-${Date.now()}-${notificationCounter++}`,
      type,
      title,
      message,
      taskId,
      read: false,
      createdAt: new Date()
    };

    // Check for duplicates using the ref
    const isDuplicate = notificationsRef.current.some(n => 
      n.type === type && 
      n.taskId === taskId && 
      n.message === message &&
      !n.read
    );

    if (!isDuplicate) {
      setNotifications(prev => [notification, ...prev]);
      toast(message, {
        icon: type === 'task_overdue' ? '⚠️' : '🔔',
        duration: 5000,
      });
    }
  }, []);

  useEffect(() => {
    const checkTasks = () => {
      const now = new Date();
      
      tasks.forEach(task => {
        const dueDate = new Date(task.dueDate);
        const timeDiff = dueDate.getTime() - now.getTime();
        const minutesUntilDue = Math.floor(timeDiff / (1000 * 60));

        if (minutesUntilDue === 60 && task.status !== 'completed') {
          addNotification({
            type: 'task_due_soon',
            title: 'Task Due Soon',
            message: `Task "${task.name}" is due in 1 hour`,
            taskId: task.id
          });
        }

        if (minutesUntilDue < 0 && task.status !== 'completed') {
          addNotification({
            type: 'task_overdue',
            title: 'Task Overdue',
            message: `Task "${task.name}" is overdue`,
            taskId: task.id
          });
        }
      });
    };

    checkTasks();
    const interval = setInterval(checkTasks, 60000);
    return () => clearInterval(interval);
  }, [tasks, addNotification]);

  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === notificationId
          ? { ...notification, read: true }
          : notification
      )
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  }, []);

  const deleteNotification = useCallback((notificationId: string) => {
    setNotifications(prev =>
      prev.filter(notification => notification.id !== notificationId)
    );
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        clearAllNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotificationContext() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotificationContext must be used within a NotificationProvider');
  }
  return context;
}