import React, { createContext, useContext, useState } from 'react';
import { Task } from '../types/Task';
import toast from 'react-hot-toast';

interface TaskContextType {
  tasks: Task[];
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'progress'>) => void;
  toggleTaskStatus: (taskId: string) => void;
  deleteTask: (taskId: string) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export function TaskProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      name: "Clean Room",
      description: "Vacuum and organize",
      assignedMemberId: "1",
      dueDate: new Date(),
      progress: 75,
      status: "in_progress",
      category: "housework",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: "2",
      name: "Math Homework",
      description: "Complete algebra exercises",
      assignedMemberId: "2",
      dueDate: new Date(Date.now() + 86400000),
      progress: 100,
      status: "completed",
      category: "homework",
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ]);

  const addTask = (newTask: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'progress'>) => {
    const task: Task = {
      ...newTask,
      id: Date.now().toString(),
      progress: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setTasks(prevTasks => [...prevTasks, task]);
    toast.success('Task created successfully!');
  };

  const toggleTaskStatus = (taskId: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId
          ? {
              ...task,
              status: task.status === 'completed' ? 'in_progress' : 'completed',
              progress: task.status === 'completed' ? task.progress : 100,
              updatedAt: new Date()
            }
          : task
      )
    );
    const task = tasks.find(t => t.id === taskId);
    const newStatus = task?.status === 'completed' ? 'in progress' : 'completed';
    toast.success(`Task marked as ${newStatus}`);
  };

  const deleteTask = (taskId: string) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
    toast.success('Task deleted');
  };

  const updateTask = (taskId: string, updates: Partial<Task>) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId
          ? { ...task, ...updates, updatedAt: new Date() }
          : task
      )
    );
    toast.success('Task updated');
  };

  return (
    <TaskContext.Provider value={{ tasks, addTask, toggleTaskStatus, deleteTask, updateTask }}>
      {children}
    </TaskContext.Provider>
  );
}

export function useTaskContext() {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTaskContext must be used within a TaskProvider');
  }
  return context;
}